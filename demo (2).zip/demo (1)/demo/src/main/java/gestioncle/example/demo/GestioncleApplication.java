package gestioncle.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestioncleApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestioncleApplication.class, args);
	}

}
