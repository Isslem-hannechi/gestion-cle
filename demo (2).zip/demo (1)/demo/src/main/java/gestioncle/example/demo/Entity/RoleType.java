package gestioncle.example.demo.Entity;

public enum RoleType {
	admin,
	chefS,
	agentS,
	superI

}
