package gestioncle.example.demo.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity 
public class User {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	 private Long userId;

	    private String nom;
	    private String prenom;
	    private String CIN;
	    private String TEL;
	    private String login;
	    private String password;
	   
	    private RoleType role;

		public Long getUserId() {
			return userId;
		}

		public void setUserId(Long userId) {
			this.userId = userId;
		}

		public String getNom() {
			return nom;
		}

		public void setNom(String nom) {
			this.nom = nom;
		}

		public String getPrenom() {
			return prenom;
		}

		public void setPrenom(String prenom) {
			this.prenom = prenom;
		}

		public String getCIN() {
			return CIN;
		}

		public void setCIN(String cIN) {
			CIN = cIN;
		}

		public String getTEL() {
			return TEL;
		}

		public void setTEL(String tEL) {
			TEL = tEL;
		}

		public String getLogin() {
			return login;
		}

		public void setLogin(String login) {
			this.login = login;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}

		public RoleType getRole() {
			return role;
		}

		public void setRole(RoleType role) {
			this.role = role;
		}

}
