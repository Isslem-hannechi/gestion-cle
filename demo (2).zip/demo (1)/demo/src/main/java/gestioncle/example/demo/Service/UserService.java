package gestioncle.example.demo.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gestioncle.example.demo.Entity.User;
import gestioncle.example.demo.Repository.UserRep;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRep userRepository;

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public Optional<User> getUserById(Long userId) {
        return userRepository.findById(userId);
    }

    public User createUser(User user) {
        return userRepository.save(user);
    }

    public User updateUser(Long userId, User userDetails) {
        Optional<User> optionalUser = userRepository.findById(userId);
        if (optionalUser.isPresent()) {
            User existingUser = optionalUser.get();
            existingUser.setNom(userDetails.getNom());
            existingUser.setPrenom(userDetails.getPrenom());
            existingUser.setCIN(userDetails.getCIN());
            existingUser.setTEL(userDetails.getTEL());
            existingUser.setLogin(userDetails.getLogin());
            existingUser.setPassword(userDetails.getPassword());
            existingUser.setRole(userDetails.getRole());
            return userRepository.save(existingUser);
        } else {
            return null; // Gérer l'absence de l'utilisateur comme vous le souhaitez
        }
    }

    public void deleteUser(Long userId) {
        userRepository.deleteById(userId);
    }

	public gestioncle.example.demo.Controller.User createUser(gestioncle.example.demo.Controller.User user) {
		// TODO Auto-generated method stub
		return null;
	}

	public gestioncle.example.demo.Controller.User updateUser(Long id,
			gestioncle.example.demo.Controller.User userDetails) {
		// TODO Auto-generated method stub
		return null;
	}
}
